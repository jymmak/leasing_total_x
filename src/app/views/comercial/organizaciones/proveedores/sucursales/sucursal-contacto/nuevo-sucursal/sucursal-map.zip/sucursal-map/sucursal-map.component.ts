import { Component, ViewChild, OnInit } from '@angular/core';
import { ToastPlugin } from "../../../../../../../../plugins/toast.plugin";
import { Router, ActivatedRoute } from '@angular/router';
import { NuevoSucursalService } from '../nuevo-sucursal.service';
declare var $: any;



@Component({
    selector: 'sucursal-map',
    templateUrl: 'sucursal-map.template.html',
    providers: [
        ToastPlugin
    ]
})
export class SucursalMapComponent implements OnInit {
    //select
    public idprov: number;
    public sucursal: number;
    public markers: any[];
    public datosProveedor: any[];
    public marker: any[];
    public latitud: number;
    public longitud: number;
    lat: number = -12.0999595;
    lng: number = -76.9703576;
    zoom: number = 15;


    constructor(private activatedRoute: ActivatedRoute,
        private _sucrusalservice: NuevoSucursalService) {

        this.idprov = 0;
        // validar la url
        this.activatedRoute.params.subscribe(params => {
            this.idprov = Number(params.id);
            this.sucursal = Number(params.sucursal);
            if (params.sucursal) {
                this.idprov = parseInt(params.id, 10);
                this.sucursal = parseInt(params.sucursal, 10);
                this.consultarProveedor(this.sucursal);
            } else {
                this.sucursal = 0;
            }
        });
    }


    ngOnInit() {

        this.addMarkers();

    }

    consultarProveedor(id) {
        this._sucrusalservice.consultar(id).subscribe(
            response => {
                (response['sucursal'][0]);
                this.datosProveedor = response['sucursal']
                // this.addMarkers();
            },
            error => {
                console.log(error);
            }
        );
    }


    addMarkers() {
        // this.datosProveedor.forEach(element => {
        //     // this.latitud = element.latitud,
        //     // this.longitud = element.longitud
        //     this.latitud = -12.0999595;
        //     this.longitud = -76.9703576;

        // });
        this.markers = this.marker = [
            {
                lat: -12.0999595,
                lng: -76.9703576,
                draggable: true

            },

        ]
    }


    clickedMarker(event, i) {
        console.log(event);
        console.log(i);
        var map;
        // google.maps.event.addListener(map,'click',function(event) {
        //     // document.getElementById('latlongclicked').value = event.latLng.lat()
        //     // document.getElementById('lotlongclicked').value =  event.latLng.lng()
        // });

    }
}
