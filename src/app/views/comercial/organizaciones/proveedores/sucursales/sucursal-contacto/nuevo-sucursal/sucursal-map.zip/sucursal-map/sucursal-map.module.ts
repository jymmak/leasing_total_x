import { NgModule } from "@angular/core";
import { SucursalMapComponent  } from "./sucursal-map.component";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from "@angular/common";
import { AgmCoreModule } from "@agm/core";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
    declarations: [SucursalMapComponent ],
    imports: [
        FormsModule,
        ReactiveFormsModule,
        BrowserModule,
        CommonModule,
        // NgbModule.forRoot(),
        // AgmCoreModule.forRoot({
        //     apiKey: 'AIzaSyBy4Xx0uzXTf9dnk9n0BqpvhNe0il7Gd4Q'
        // })

    ],
    exports: [SucursalMapComponent ]
})

export class SucursalMapModule { }
